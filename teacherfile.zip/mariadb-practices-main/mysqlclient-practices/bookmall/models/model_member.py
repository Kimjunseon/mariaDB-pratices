def insert():
    print("member 추가")

def findall():
    print("member list 가져오기")